#!/usr/bin/python3
import nltk
from nltk.wsd import lesk 
from nltk.corpus import wordnet as wn
import wikipedia
from nltk.parse import CoreNLPParser    
import itertools
from collections import OrderedDict
import os

def sfNERTagger(rawText):
    '''get the raw text from a file and convert that to a list with tuples of each word with a StanFord annotated NER-tag'''
    parser = CoreNLPParser(url='http://localhost:9000', tagtype='ner')
    return list(parser.tag(rawText.split()))

def sfNERWriter(POSFile, NERList):
    '''Takes output of sfNERTagger() -->NERList, iters over the POSFile, if NERList[index][1] is meaningful: add the appropriate tag'''
    for lineNumber,line in enumerate(POSFile):
        if line[3]

def main():

if __name__ == "__main__":
    main()